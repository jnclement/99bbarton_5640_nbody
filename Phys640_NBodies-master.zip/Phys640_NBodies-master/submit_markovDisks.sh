#!/bin/bash

#Submission script to submit markovDisks batch jobs

#SBATCH --time=10:00:00 #Time scales linearly with N_STEPS - N_STEPS = 1e6 = 30s -> 1e9 ~8.33hrs
#SBATCH -A phys-5640
#SBATCH --output=markovDisks.log #Note that jobs submitted simultaneously must be in diff dirs to avoid log file name conflict
#SBATCH --partition=standard
#SBATCH --mail-type=begin 
#SBATCH --mail-type=end # send email when job ends
#SBATCH --mail-user=bbarton@virginia.edu

source ~rjh2j/phys5640/opt/p5640_py2.sh

N_STEPS=1000000000 #1e9

./markovDisks ${N_STEPS} -b

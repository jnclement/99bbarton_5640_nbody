//Implementation of Krauth Alg. 2.9 "Markov-Disks" - with cells optimization

//The script can be run passing an integer number of steps e.g. ./markovDisks 100000
//Passing a -b flag will prevent graphics from being displayed
//Histograms for 4 different diameter configurations are plotted to markov.png and written to markovDisksHists.root


#include "particle.h"
#include "TRandom3.h"
#include "TH1F.h"
#include "TCanvas.h"
#include "TROOT.h"
#include "TApplication.h"
#include "TStyle.h"
#include "TFile.h"
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>

using namespace std;


//--------------------------------------------   Constants & Prototypes   ------------------------------------------------//
const int N = 64;
double DIAMETER = 0.0125;
const double WALL_XMIN = 0; //Wall locations
const double WALL_XMAX = 8;
const double WALL_YMIN = WALL_XMIN;
const double WALL_YMAX = WALL_XMAX;
int N_STEPS = 1e6;
const int START_PLOTTING = 1000; //THe step after which to start plotting
const int NUM_SIMS = 4; //Number of times to repeat the simulation
const double MIN_STEP_SIZE = 0.01;
const double MAX_STEP_SIZE = 0.8; //The maximum step a particle can take in a single dimension (can take in both dims)
const int NUM_CELLS = 80; //Number of cells per row and column

void initialize_grid(Particle *particles[]);
void initialize_random(Particle *particles[]);
int generateStep(Particle *part, double pos[], bool invalDirs[], TRandom3 *randGen);
bool validStep(Particle *particles[], int pInd, double pos[], int cells[80][80][10]);
void markovStepper(Particle *particles[], TH1F *hist, int cells[80][80][10]); 
void initializeCells(int cells[80][80][10], Particle *particles[]);
int getCellNum(double x, double y, int *cellX, int *cellY);


int main(int argc, char *argv[])
{
  TFile *outFile = new TFile("markovDisksHists.root", "RECREATE");
  //Initialize ROOT stuff
  TApplication theApp("App", &argc, argv); // init ROOT App for displays
  TCanvas *canv = new TCanvas("canv", "Markov Chain Simulation Results", 800, 600);
  // TH1F *xHist = new TH1F("xHist", "X Positions", 10 * (WALL_XMAX - WALL_XMIN), WALL_XMIN, WALL_XMAX);
  // xHist->SetXTitle("x");
  // xHist->SetYTitle("Count");
  canv->Divide(3,2);
  TH1F *hists[NUM_SIMS]; 
  string title = "x Values for d=";
  string name = "xHist_";
  
  //Allow the number of steps to be contolled via a command line parameter
  if (argc == 2)
    {
      N_STEPS = atof(argv[1]);

      if (N_STEPS <= START_PLOTTING)//Avoid empty hists
	{
	  N_STEPS= START_PLOTTING * 100;
	  cout <<"\nAdjusted N_STEPS to " << N_STEPS << endl;
	}
    }

  Particle *particles[N];  //Array of particle
  int cells[NUM_CELLS][NUM_CELLS][10]; //The grid of cells to use to optimize state searches
  //The third dim stores indices in particles array of the particles in that cell
  //cout << cells[0][0][9] << endl;

  for (int i = 1; i <= NUM_SIMS; i++)
    {
      hists[i-1] = new TH1F((name + i),(title + DIAMETER), 10 * (WALL_XMAX - WALL_XMIN), WALL_XMIN, WALL_XMAX);
      hists[i-1]->SetTitle(title + DIAMETER);
      
      hists[i-1]->SetXTitle("x");
      hists[i-1]->SetYTitle("Counts");
      if ( i == 5)
	hists[i-1]->SetLineColor(6);
      else
	hists[i-1]->SetLineColor(i);

      //initialize_grid(particles);
      initialize_random(particles);
      initializeCells(cells, particles);
      cout << "\nInitialized simulation " << i  << "/" << NUM_SIMS  <<" with diameter = " << DIAMETER<< endl;
      cout << "Running simulation..." << endl;
      markovStepper(particles, hists[i-1], cells);
      cout << "Completed simulation " << i << "/" << NUM_SIMS << endl;

      
      canv->cd(6); 
      hists[i-1]->Draw("same"); //Make a combined overlayed plot - This can get ugly but shows like of pattern
      canv->cd(i);
      hists[i-1]->Draw(); //Plot each individually

      hists[i-1]->Write(name + i); //Write the histogram to the root file

      DIAMETER *= 2;      
    }
  
  cout << "\nWrote histograms to markovDisksHists.root" << endl;
  canv->SaveAs("markov.png");
  outFile->Close();

  //Passing a -b flag will turn off graphics displays - suitable for batch submissions
  if (!gROOT->IsBatch())
    {
      cout << "\nEnter ^C to close" << endl;
      theApp.Run();
    }

  

  return 0;
}


//Since we will melt out the initial state, simply initialize the particles to a grid 
void initialize_grid(Particle *particles[])
{
  int row = 0;
  int col = 0;
  double spacer = DIAMETER;

  for (int p = 0; p < N; p++)
    {
      double x = WALL_XMIN + DIAMETER + (col * (spacer + DIAMETER)); //Generate an x within the box and check
      if (x + DIAMETER/2 > WALL_XMAX)
	{
	  row++;
	  col = 0;
	  x = WALL_XMIN + DIAMETER;
	}
      double y = WALL_YMIN + DIAMETER + (row * (spacer + DIAMETER)); //Generate the next y within the box and check
      if( y + DIAMETER/2 > WALL_YMAX)
	{
	  cout << "ERROR - Box size exceeded" << endl;
	  exit(1);
	}

      particles[p] = new Particle(x, y, DIAMETER); //Iniitialize a new particle at (x,y) with v=0 and d=DIAMETER
    }
}

//Initialize using random positions
void initialize_random(Particle *particles[])
{
  TRandom3 *randGen = new TRandom3();
  randGen->SetSeed();
  
  double x;
  double y;

  for (int p = 0; p < N; p++)
    {
      bool filled = false;
      while (!filled)
	{
	  x = randGen->Uniform(WALL_XMIN + (DIAMETER/2), WALL_XMAX + (DIAMETER/2)); 
	  y = randGen->Uniform(WALL_YMIN + (DIAMETER/2), WALL_YMAX + (DIAMETER/2)); 
	  Particle *part = new Particle(x, y, DIAMETER); //Iniitialize a new particle at (x,y) with v=0 and d=DIAMETER
	  

	  bool overlaps = false;
	  for (int i = 0; i < p; i++)
	    {
	      if (part->overlaps(*particles[i]))
		{
		  overlaps = true;
		  break;
		}
	    }
	  if (!overlaps)
	    {
	      particles[p] = part;
	      filled = true;
	    }
	}
    }
}


/* Generates a proposed (x,y) step position for the particle p
   @param p : A pointer to the particle to examine
   @param pos : An array of length 2 to put the generated x & y positions in
   @param invalDirs : An array of length 8. True if step direction was already tried for this particle but was invalid
   @returns : the direction of the step

   Direction Mapping:
   0 = up
   1 = up-right
   2 = right
   3 = down-right
   4 = down
   5 = down-left
   6 = left
   7 = up-left 
 */
int generateStep(Particle *p, double pos[], bool invalDirs[], TRandom3 *randGen)
{
  int stepDir;
  do
    { //Randomly choose a step direction - skipping any one that has already been tried
      stepDir  = randGen->Integer(8); 
    }
  while(invalDirs[stepDir]);


  double stepSize = randGen->Uniform(MIN_STEP_SIZE, MAX_STEP_SIZE);
    
  if (stepDir <= 1 || stepDir == 7) //If any up step
    pos[1] = p->y + stepSize;
  else if (stepDir >= 3 && stepDir <= 5) //If any down step
    pos[1] = p->y - stepSize;
  else
    pos[1] = p->y;

  if (stepDir >= 1 && stepDir <= 3) //If any right step
    pos[0] = p->x + stepSize;
  else if (stepDir >= 5 && stepDir <= 7) //If any left step
    pos[0] = p->x - stepSize;
  else
    pos[0] = p->x;

  //Handle periodic boundary conditions here:
  if (pos[0] < WALL_XMIN)
    pos[0] = WALL_XMAX - (WALL_XMIN - pos[0]);
  else if (pos[0] > WALL_XMAX)
    pos[0] = WALL_XMIN + (pos[0] - WALL_XMAX);

  if (pos[1] < WALL_YMIN)
    pos[1] = WALL_YMAX - (WALL_YMIN - pos[1]);
  else if (pos[1] > WALL_YMAX)
    pos[1] = WALL_YMIN + (pos[1] - WALL_YMAX);
  
  return stepDir;
}


/*Cells implementation fir step szie that limits interactions to only neighboring eight cells
  Return true if a transition is valid (particles will not overlap) - false otherwise
  @param particles : the array of particles
  @param pInd : the particle to examine
  @param pos : A 2d array containing the proposed (x,y) position of the particle at pInd
 */
bool validStep(Particle *particles[], int pInd, double pos[], int cells[80][80][10])
{
  bool overlaps = false;

  Particle *testPart = new Particle(pos[0], pos[1], DIAMETER);

  int row, col;
  getCellNum(particles[pInd]->x, particles[pInd]->y, &row, &col);

  for (int p = 0; p < 10; p++)
    {
      if (cells[row][col][p] == -1)
	continue;
      
      overlaps = particles[cells[row][col][p]]->overlaps(*testPart);
      if (overlaps)
	{
	  delete testPart;
	  return false;
	}
    }	  

  delete testPart;
  return true;
}



// Steps each particle NSteps times, checking if each state is valid before stepping
void markovStepper(Particle *particles[], TH1F *hist, int cells[80][80][10])
{
  TRandom3 *randGen = new TRandom3();
  randGen->SetSeed();

  for (int s = 0; s < N_STEPS; s++) //RUn for N_STEPS
    {
      for (int p = 0; p < N; p++) //Walk each particle
	{
	  double newPos[2];
	  int stepDir;
	  bool invalDirs[8] = {false};
	  int numValDirs = 8;
	 
	  while (numValDirs > 0)
	    {
	      stepDir = generateStep(particles[p], newPos, invalDirs, randGen);

	      if (validStep(particles, p, newPos, cells)) //If the proposed step was valid, take it
		{
		  particles[p]->update(newPos[0], newPos[1], 0, 0);
		  // int dummy;
		  // particles[p]->setCell(getCellNum(newPos[0], newPos[1], &dummy, &dummy)); //Update the particles cell number

		  break;
		}
	      else //Otherwise, note the failed step and keep searching until no valid steps are available or one is found
		{
		  invalDirs[stepDir] = true;
		  numValDirs--;
		}
	    }
	}

      if (s > START_PLOTTING)
	{
	  for (int i = 0; i < N; i++)
	    {
	      hist->Fill(particles[i]->x);
	    }
	}
    }

}



//Return the cell number where the particle is and fill the row and column indices - cell number corresponds to flattened repres
int getCellNum(double x, double y, int *row, int *col)
{
  double cellWidth = 0.1 * WALL_XMAX;
  *row = (int) x / cellWidth; //Take advantage of integer flooring to account for zero-indexing in cells arrays
  *col = (int) y / cellWidth;
  
  return (*col * NUM_CELLS) + *row; //2D arrays are row-major, return the index of the flattened 2D array

}

//Initialize the grid of cells with values - put indices of the particles

void initializeCells(int cells[80][80][10], Particle *particles[])
{
  //FIrst initialize al lthe cells values to -1
  for (int r = 0; r < NUM_CELLS; r++)
    {
      for (int c = 0; c< NUM_CELLS; c++)
	{
	  for (int p = 0; p < 10; p++)
	    {
	      cells[r][c][p] = -1;
	    }
	}
    }
  

  int row;
  int col;
  for (int pNum = 0; pNum < N; pNum++)
    {
      getCellNum(particles[pNum]->x, particles[pNum]->y, &row, &col);
      // particles[pNum]->setCell(cellNum); //Store the cell number in the particle
      
      for (int i = 0; i < 10; i++) //Store the particle index in the next available space in the arr in the correct cell
	{
	  if (cells[row][col][i] == -1)
	    {
	      cells[row][col][i] = pNum;
	      break;
	    }
	}
    }

}




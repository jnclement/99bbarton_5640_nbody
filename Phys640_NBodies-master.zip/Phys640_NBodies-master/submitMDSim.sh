#!/bin/bash

#SBATCH --time=1:00:00
#SBATCH -A phys-5640
#SBATCH --output=mdSimulator_batch.log
#SBATCH --partition=standard

source ~rjh2j/phys5640/opt/p5640_py2.sh

./mdSimulator_batch -b

//Molecular dynamics of particles in a box with hard walls through sampling
//Based of Krauth ex2.6
//Team N-Body Problem

#include <cmath>
#include "particle.h"
#include "TRandom2.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TCanvas.h"
#include "TROOT.h"
#include "TApplication.h"
#include "TStyle.h"
#include <cstdio>
#include <cstdlib>
#include <iostream>



using namespace std;

//------------------------------------ Control Parameters, Constants, & Prototypes -------------------------------------//


bool PERIODIC_BCS = false; // Control param for periodic vs hard wall BCs
const double WALL_XMIN = 0; //Wall locations
const double WALL_XMAX = 5;
const double WALL_YMIN = 0;
const double WALL_YMAX = 5;
const int WALL_ID_TOP = 0; //Wall ID numbers
const int WALL_ID_RIGHT = 1;
const int WALL_ID_BOTTOM = 2;
const int WALL_ID_LEFT = 3;
const int N = 4; //Number of particles
const int N_INTERACTIONS = 1000;
const double DIAMETER = 1;
const double LARGE_NUM = 1e10; //Default and "large value" for min calcs

void initialize(vector<Particle> &particles, int nparticles);
double* diff_vec(Particle &p1, Particle &p2, double xi[]);
void box_it(double* xi);


//---------------------------------------------------- Main  -----------------------------------------------------------//

int main(int argc, char *argv[])
{
  // XInitThreads();
  TApplication theApp("App", &argc, argv); // init ROOT App for displays

  vector<Particle> *particles = new vector<Particle>();
  
  
  TCanvas *c1 = new TCanvas("c1","Histograms",900,700);
  //c1->Divide(2,2);
  TH1 *xhist = new TH1F("xhist","Histogram of X values",500,0,5);
  for(int i = 0; i < 100000; i++)
    {
      initialize(*particles, N);
      for(int j = 0; j < N; j++)
	{
	  xhist->Fill(particles->at(j).x);
	}
      particles->clear();
    }

  c1->cd();
  xhist->Draw();

  theApp.Run();

  return 0;
}

void initialize(vector<Particle> &particles, int nparticles)
{
  double newx;
  double newy;
  double newvy;
  double newvx;
  bool overlaps = false;

  while(true)
    {
      for(int i = 0; i < nparticles; i++)
	{
	  newx = 5 * (rand()/(1.0 + RAND_MAX));
	  newy = 5 * (rand()/(1.0 + RAND_MAX));
	  newvx = (2 * (rand()/(1.0 + RAND_MAX))) - 1;
	  newvy = (2 * (rand()/(1.0 + RAND_MAX))) - 1;
	  Particle *pPtr = new Particle(newx, newy, newvx, newvy, DIAMETER);
	  Particle p = *pPtr;
	  particles.push_back(p);
	}
      for (unsigned int j = 0; j < particles.size(); j++)
	{
	  if((particles[j].x + particles[j].d/2) > WALL_XMAX)
	    {
	      overlaps = true;
	      break;
	    }
	  if(particles[j].x - particles[j].d/2 < WALL_XMIN)
	    {
	      overlaps = true;
	      break;
	    }
	  if((particles[j].y + particles[j].d/2) > WALL_YMAX)
	    {
	      overlaps = true;
	      break;
	    }
	  if((particles[j].y - particles[j].d/2) < WALL_YMIN)
	    {
	      overlaps = true;
	      break;
	    }
	  for(unsigned int k = j+1; k < particles.size(); k++)
	    {
	      if(particles[j].overlaps(particles[k]))
		{
		  overlaps = true;
		  break;
		}
	    }
	  if(overlaps)
	    {
	      break;
	    }
	}
      if(!overlaps)
	{
	  break;
	}
      particles.clear();
      overlaps = false;
    }
  
}
// Updates a particle's position to remain in the box, xi is the position vector
// Source: Krauth Algo 2.5
void box_it(double* xi)
{
  double x = std::fmod(xi[0], WALL_XMAX - WALL_XMIN);
  if(x < 0) x += WALL_XMAX - WALL_XMIN;
  double y = std::fmod(xi[1], WALL_YMAX - WALL_YMIN);
  if(y < 0) y += WALL_YMAX - WALL_YMIN;
  
  xi[0] = x;
  xi[1] = y;
}


// Calculates the distance between two particles in the periodic boundary
// case, may be able to utilized in the particle collision kinematics as normal
// Source: Krauth Algo 2.6
//@param : xi double array of length 2
double* diff_vec(Particle &p1, Particle &p2, double xi[])
{
 
  xi[0] = p1.x - p2.x;
  xi[1] = p1.y - p2.y;
  box_it(xi);
  if(xi[0] > (WALL_XMAX - WALL_XMIN) / 2) xi[0] -= (WALL_XMAX - WALL_XMIN);
  if(xi[1] > (WALL_YMAX - WALL_YMIN) / 2) xi[1] -= (WALL_YMAX - WALL_YMIN);

  return xi;
}


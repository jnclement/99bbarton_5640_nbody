//Implementation of particle classes


#include "particle.h"
#include <cmath>
#include <iostream>
using namespace std;
Particle::Particle(){}
Particle::Particle(const Particle &pOrig)
{
  this->x = pOrig.x;
  this->y = pOrig.y;
  this->vx = pOrig.vx;
  this->vy = pOrig.vy;
  this->d = pOrig.d;
}
Particle::Particle(double x, double y, double vx, double vy, double d)
{
  this->x = x;
  this->y = y;
  this->vx = vx;
  this->vy = vy;
  this->d = d;
}
Particle::Particle(double x, double y, double d)
{
  this->x = x;
  this->y = y;
  this->vx = 0;
  this->vy = 0;
  this->d = d;
}


Particle::~Particle(){} //No dynamically allocated memory so do nothing


/* OBSOLETE
   Get the time window of the collision region for the particle
   @param x : The x coordinate of the collision centroid
   @param y : The y coordinate of the collision centroid
   @param timeWindow : Double arr of length 3 to store the time window result in
   Second value is the time the particle will be centered on (x,y)
   The first value is the time when the partcle will be centered at -1.5 diameters away from centroid, and the third +1.5 diameters.
   If the particle will not reach (x,y), the three returned values will be -1.
 */
double Particle::getTimeWindow(double x, double y, double timeWindow[3]) const
{
   //Solve x_c = x_0 + v_x*t , y_c = y_0 + v_y*t for t. If either are zero, use the other t
  double tCollis_x = (x - this->x) / this->vx;
  double tCollis_y = (y - this->y) / this->vy;
  if (tCollis_x == tCollis_y) //Collision point is on the trajectory - trajectory not vertical or horizontal
    timeWindow[1] = tCollis_x; 
  else if(tCollis_x == 0) //Collision is on the trajectory - horizontal
    timeWindow[1] = tCollis_y;
  else if(tCollis_y == 0) //Collision is on the trajectory - vertical
    timeWindow[1] = tCollis_x;
  else //Collision point is not on the trajectory
    {
      timeWindow[0] = -1;
      timeWindow[1] = -1;
      timeWindow[2] = -1;
      return -1;
    }

  //Calculate the minimum and maximum times for the collision window
  double dist = this->d * 1.5; //1.5 diameters on either side of the collision centroid define the collision region
  double vMag = sqrt((this->vx * this->vx) + (this->vy * this->vy));
  timeWindow[0] = timeWindow[1] - (dist / vMag);
  if (timeWindow[0] < 0)
    timeWindow[0] = 0; //If the particle is already at the collision location
  timeWindow[2] = timeWindow[1] + (dist / vMag);

  return timeWindow[1];
}


//Update the particle kinematicS
void Particle::update(double newX, double newY, double newVx, double newVy)
{
  this->x = newX;
  this->y = newY;
  this->vx = newVx;
  this->vy = newVy;
}

//Returns true if this overlaps with b, false otherwise
bool Particle::overlaps(Particle b)
{
  double dx2 = pow(this->x - b.x,2);
  double dy2 = pow(this->y - b.y,2);
  double dist = sqrt(dx2+dy2);
  if (dist < ((this->d)/2+(b.d)/2))
    {
      return true;
    }
  return false;
}

//Return the speed ofthe particle
double Particle::getVelocity()
{
  return sqrt((vx * vx) + (vy * vy));
}

//Move the particle for a time
void Particle::propagate(double time)
{
  this->x += this->vx * time;
  this->y += this->vy * time;
}

//Print the contents of the particle
void Particle::print()
{
  printf("particle( x = %6.3lf\ty = %6.3lf\t vx = %6.3lf\t vy = %6.3lf\t v = %6.3lf\t d = %3.2lf )\n",x, y, vx ,vy, getVelocity(), d);
}

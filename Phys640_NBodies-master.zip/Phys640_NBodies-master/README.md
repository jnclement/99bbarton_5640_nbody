# Phys640_NBodies
Team N-Body Problem
-Joey Clement
-Drew Wilkers
-Ben Barton

Everything can be compiled with "make"

mdSimulator.cpp and its executable form mdSimulator performs molecular dynamics simulations via propagation of the particles.

mdSimulator2.6.cpp and its executabler repeatedly sample the initialization of the particles in a box with hard BCs a la Krauth 2.6

mdSimulator2.7.cpp and its execuable does the same except with periodic BCs a la Krauth 2.7




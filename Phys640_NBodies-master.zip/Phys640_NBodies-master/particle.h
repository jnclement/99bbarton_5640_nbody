//Class to represent a particle


class Particle{

 public:
  double x;
  double y;
  double vx;
  double vy;
  double d;

  Particle();
  Particle(const Particle &p);
  Particle(double x, double y, double vx, double vy, double d);
  Particle(double x, double y, double d); // Will set velocities to zero
  ~Particle();
  double getTimeWindow(double collisX, double collisY, double timeWindow[3]) const; //Returns an array of length 3 w/ the min, centroid, and max time of the 3d collision region, where d is the diameter of the disc
  void update(double newX, double newY, double newVx, double newVy); //Update all of the particle kinematic fields
  bool overlaps(Particle b); //Checks if this particle overlaps the specified particle
  double getVelocity(); //Returns the magnitude of the velocity
  void propagate(double time); //Propagate the particle time * velocity
  void print(); //Print the particle contents
};

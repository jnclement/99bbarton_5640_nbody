//Molecular dynamics simulation based on Krauth event-disks algorithm 2.1
//Team N-Body Problem

#include <cmath>
#include "particle.h"
#include "TRandom3.h"
#include "TH1F.h"
#include "TH2F.h"
#include "TCanvas.h"
#include "TROOT.h"
#include "TApplication.h"
#include "TStyle.h"
#include <cstdio>
#include <cstdlib>
#include <iostream>



using namespace std;

//------------------------------------ Control Parameters, Constants, & Prototypes -------------------------------------//


bool PERIODIC_BCS = false; // Control param for periodic vs hard wall BCs
const double WALL_XMIN = 0; //Wall locations
const double WALL_XMAX = 5;
const double WALL_YMIN = 0;
const double WALL_YMAX = 5;
const int WALL_ID_TOP = 0; //Wall ID numbers
const int WALL_ID_RIGHT = 1;
const int WALL_ID_BOTTOM = 2;
const int WALL_ID_LEFT = 3;
const int N = 4; //Number of particles
const int N_INTERACTIONS = 1000;
const double DIAMETER = 0.1;
const double LARGE_NUM = 1e10; //Default and "large value" for min calcs


int getWallCollisTime(Particle &p, double *collisTime);
void wallCollision_hard(Particle &p, int wallID, double collisionTime);
void wallCollision_periodic(Particle &p, int wallID);
void initialize(vector<Particle> &particles, int nparticles);
double* diff_vec(Particle &p1, Particle &p2, double xi[]);
void box_it(double* xi);
double collision_time(Particle &p1, Particle &p2);
void particleCollision(Particle &p1, Particle &p2, double collisionTime);
void pair_collision(Particle &p1, Particle &p2, double collisionTime);
void printInteractionMatrix(double matrix[][N+4]);
void visualize(vector<Particle> *particles, TCanvas *canv, int pad);
void propagateAll(vector<Particle> *particles, double time, int dontPropP1, int dontPropP2);
double dot2d(double a1, double a2, double b1, double b2);

TRandom3 *randomGen;

//---------------------------------------------------- Main  -----------------------------------------------------------//

int main(int argc, char *argv[])
{
  TApplication theApp("App", &argc, argv); // init ROOT App for displays

  double matrix[N][N+4]; //Interaction matrix storing times to collisions between each particle and particle-wall
  vector<Particle> *particles = new vector<Particle>(); //Vector of particles in the box

  //INitialize the interaction matrix to default (large value)
  for (int r = 0; r < N; r++)
    {
      for (int c = 0; c < N + 4; c++)
	{
	  matrix[r][c] = LARGE_NUM;
	}
    }
  
  initialize(*particles, N);

  TCanvas *c1 = new TCanvas("c1","Histograms",1200,450);
  c1->Divide(3,1);
  TH1 *xhist = new TH1F("xhist","X Positions",100,0,5);
  TH1 *vxhist = new TH1F("vxhist","Vx Values",100,-2,2);
  TH1 *vhist = new TH1F("vhist","V Values",100,0,2);
  gStyle->SetOptStat(false);

  //Simulate the interactions
  int numPCs = 0;
  int numWCs = 0;
  for (int i = 0; i < N_INTERACTIONS; i++)
    {
      double wallCollisTime;
      int wallID;
      for (int ind1 = 0; ind1< N; ind1++)
	{
	  Particle p1 = particles->at(ind1);

	  wallID = getWallCollisTime(p1, &wallCollisTime); //Find wall collisTime and ID
	  for (int w = 0; w < 4; w++)
	    {
	      if (w == wallID)
		matrix[ind1][N + w] = wallCollisTime;
	      else
		matrix[ind1][N + w] = 1e10;      
	    }

	  for (int ind2 = ind1 + 1; ind2 < N; ind2++) //Find all particle collision possibilities
	    {
	      double partCollisTime;
	      if (PERIODIC_BCS)
		{
		  double diff[2];
		  diff_vec(p1, particles->at(ind2), diff);
		  partCollisTime = sqrt( (diff[0] * diff[0]) + (diff[1] + diff[1])) / p1.getVelocity(); //Divide mag of diff vector by mag of vel
		}
	      else
		{
		  partCollisTime = collision_time(p1, particles->at(ind2));
		  if (partCollisTime < 0)
		    partCollisTime = LARGE_NUM;
		}
	      matrix[ind1][ind2] = partCollisTime;
	    }
	}
      //Find he minimum particle collision time
      double minTime = LARGE_NUM;
      int minInd1 = 0;
      int minInd2 = 0;
      for(int k = 0; k < N; k++)
	{
	  
	  for(int j = 0; j < N+4; j++)
	    {
	      if (matrix[k][j] < minTime)
		{
		  minTime = matrix[k][j];
		  minInd1 = k;
		  minInd2 = j;
		}
	    }

	}
  
      //Call the appropriate collision function and update the interaction matrix if necessary
      if (minInd2 < N) // If a particle collision
	{
	  particleCollision(particles->at(minInd1), particles->at(minInd2), minTime);
	  propagateAll(particles, minTime, minInd1, minInd2); //Need to propagate all the particles to the next time
	  matrix[minInd1][minInd2] = LARGE_NUM; // Need to update intereaction matrix so the distance is not minimal
	  matrix[minInd2][minInd1] = LARGE_NUM;
	  numPCs++;

	  for (int j = 0; j < N; j++) //Fill the histograms
	    {
	      xhist->Fill(particles->at(j).x);
	      vxhist->Fill(particles->at(j).vx);
	      vhist->Fill(particles->at(j).getVelocity());
	    }
	}
      else
	{
	  wallCollision_hard(particles->at(minInd1), minInd2 - 4, minTime);
	  propagateAll(particles, minTime, minInd1, -1);
	  matrix[minInd1][minInd2] = LARGE_NUM;
	  i--;
	  numWCs++;
	}


    }
  cout << "There were " << numPCs << " particle-particle collisions and " << numWCs << " particle-wall collisions" << endl;
  
  c1->cd(1);
  xhist->Draw();
  c1->cd(2);
  vxhist->Draw();
  c1->cd(3);
  vhist->Draw();
  cout << "Enter ^C to close" << endl;
  theApp.Run();

  return 0;
}



//---------------------------------------- Initializations ------------------------------------------------------------//


//Initialize the particles in the box, ensuring zero total momentumx
void initialize(vector<Particle> &particles, int nparticles)
{
  randomGen = new TRandom3();
  randomGen->SetSeed();
  double newx;
  double newy;
  double newvy;
  double newvx;
  double absv;
  bool overlaps = false;
  int i = 0;
  double vxavg = 0;
  double vyavg = 0;


  while(i < nparticles)
    {
      newx = randomGen->Rndm();
      newy = randomGen->Rndm();
      newvx = 2*(randomGen->Rndm()-0.5);
      newvy = 2*(randomGen->Rndm()-0.5);
      Particle *pPtr = new Particle(newx, newy, newvx, newvy, DIAMETER);
      Particle p = *pPtr;
      
      for (unsigned int j = 0; j < particles.size(); j++)
	{
	  if(p.overlaps(particles[j]) || p.x+p.d > WALL_XMAX || p.x-p.d < WALL_XMIN || p.y+p.d > WALL_YMAX || p.y-p.d < WALL_YMIN)
	    {
	      overlaps = true;
	      delete pPtr;
	      break;
	    }
	}
      if(!overlaps) {
	particles.push_back(p);
	i++;
      }
      overlaps = false;
    }
  for(int k = 0; k < nparticles; k++)
    {
      vxavg += particles[k].vx/nparticles;
      vyavg += particles[k].vy/nparticles;
    }
  for(int l = 0; l < nparticles; l++)
    {
      particles[l].vx -= vxavg;
      particles[l].vy -= vyavg;
      absv = sqrt(pow(particles[l].vx,2)+pow(particles[l].vy,2));
      particles[l].vx /= absv;
      particles[l].vy /= absv;
    }
}


//---------------------------------------  Wall Collision Handling  ---------------------------------------------------//

//Returns the wall ID where the particle will collide and sets collisTime with the time of the collision 
int getWallCollisTime(Particle &p, double *collisTime)
{
  double xCollisTime = -1;
  double yCollisTime = -1;
  double rad = p.d / 2;

  //Get the possible collisions
  if (p.vx > 0)
    xCollisTime = ( WALL_XMAX - (p.x + rad) ) / p.vx;
  else
    xCollisTime = ( WALL_XMIN - (p.x + rad) ) / p.vx;

  if (p.vy > 0)
    yCollisTime = ( WALL_YMAX - (p.y + rad)) / p.vy;
  else
    yCollisTime = ( WALL_YMIN - (p.y + rad)) / p.vy;

  //Determine which collision will happen
  if (xCollisTime < 0)
    {
      *collisTime = yCollisTime;
      
      if (p.vy > 0)
	return WALL_ID_TOP;
      else
	return WALL_ID_BOTTOM;
    }
  else if (yCollisTime < 0)
    {
      *collisTime = xCollisTime;

   
      if (p.vx > 0)
	return WALL_ID_RIGHT;
      else
	return WALL_ID_LEFT;
    }
  else
    {
      *collisTime = std::min(xCollisTime, yCollisTime);

   
      if(std::min(xCollisTime, yCollisTime) == xCollisTime)
	{
	  if (p.vx > 0)
	    return WALL_ID_RIGHT;
	  else
	    return WALL_ID_LEFT;
	}
      else if(p.vy > 0)
	return WALL_ID_TOP;
      else
	return WALL_ID_BOTTOM;
    }

  return -1;
}


//Update particle p with new kinematic parameters after a elastic collision with a hard, immovable wall
void wallCollision_hard(Particle &p, int wallID, double collisionTime)
{
  double rad = p.d / 2;
  
  if (wallID == WALL_ID_TOP)
    p.update(p.x + p.vx * collisionTime, WALL_YMAX - rad, p.vx, -1 * p.vy);
  else if (wallID == WALL_ID_RIGHT)
    p.update(WALL_XMAX - rad, p.y + p.vy * collisionTime, -1 * p.vx, p.vy);
  else if (wallID == WALL_ID_BOTTOM)
    p.update(p.x + p.vx * collisionTime, WALL_YMIN + rad, p.vx, -1 * p.vy);
  else
    p.update(WALL_XMIN + rad, p.y+p.vy*collisionTime, -1 * p.vx, p.vy);
}


//Propagate particle p to the opposite wall (periodic BCs)
void wallCollision_periodic(Particle &p, int wallID)
{
  double rad = p.d / 2;
  if (wallID == WALL_ID_TOP)
    p.update(WALL_XMAX - p.x + WALL_XMIN + rad, WALL_YMIN, p.vx, p.vy);
  else if (wallID == WALL_ID_BOTTOM)
    p.update(WALL_XMAX - p.x + WALL_XMIN + rad, WALL_YMAX, p.vx, p.vy);
  else if (wallID == WALL_ID_RIGHT)
    p.update(WALL_XMIN, WALL_YMAX - p.y + WALL_YMIN + rad, p.vx, p.vy);
  else
    p.update(WALL_XMAX, WALL_YMAX - p.y + WALL_YMIN + rad, p.vx, p.vy);
}


//-------------------------------------------------------------    Pairwise Particle Collision Handling    -----------------------------------------------------//

// Calculate the time at which two particles will collide given
// initial conditions
// Source: Krauth Algo 2.2
double collision_time(Particle &p1, Particle &p2)
{
  double delta_x  = p1.x  - p2.x;
  double delta_y  = p1.y  - p2.y;
  double delta_vx = p1.vx - p2.vx;
  double delta_vy = p1.vy - p2.vy;
  // dxddv = dot product of vectors Delta x and Delta v
  // dvddv = dot product of vector Delta v with itself
  // dxddx = dot product of vector Delta x with itself
  double dxddv = (delta_x  * delta_vx) + (delta_y  * delta_vy);
  double dvddv = (delta_vx * delta_vx) + (delta_vy * delta_vy);
  double dxddx = (delta_x  * delta_x)  + (delta_y  * delta_y);
  double trace = (dxddv * dxddv) - dvddv * (dxddx - p1.d * p2.d);
  
  if(trace > 0 && dxddv < 0)
    {
      double time = -(dxddv + sqrt(trace)) / dvddv;
      // if (time < 1e-6)
      //	return LARGE_NUM;
      //      else
	return time;
    }
  else
    {
      return LARGE_NUM;  // arbitrarily large number, ie they won't collide 
    }
}

//NOTE: THIS FUNCTION IS NOT BEING USED - CAUSES VELOCITIES TO GO TO INFINITY
// Updates two particles undergoing a collision with new velocities
// Source: Krauth Algo 2.3
void pair_collision(Particle &p1, Particle &p2, double collisionTime)
{
  double delta_x  = p1.x  - p2.x;
  double delta_y  = p1.y  - p2.y;
  double dxddx = (delta_x * delta_x) + (delta_y * delta_y);
  double e_x   = delta_x / sqrt(dxddx);
  double e_y   = delta_y / sqrt(dxddx);
  double dvde  = (delta_x * e_x) + (delta_y * e_y);
  p1.update(p1.x + (p1.vx * collisionTime), p1.y + (p1.vy * collisionTime), p1.vx - e_x * dvde, p1.vy - e_y * dvde);
  p2.update(p2.x + (p2.vx * collisionTime), p2.y + (p2.vy * collisionTime), p2.vx - e_x * dvde, p2.vy - e_y * dvde);  

  }

//2D vector dot product of vector a with vector b
double dot2d(double a1, double a2, double b1, double b2)
{
  return (a1 * b1) + (a2 * b2);
}


//Reimplementation of pair_collision algo 2.3
void particleCollision(Particle &p1, Particle &p2, double collisionTime)
{
  double newX1 = p1.x + (p1.vx * collisionTime);
  double newX2 = p2.x + (p2.vx * collisionTime);
  double newY1 = p1.y + (p1.vy * collisionTime);
  double newY2 = p2.y + (p2.vy * collisionTime);
  double deltaY = p1.y - p2.y;
  double deltaX = p1.x - p2.x;
  double deltaMagSquared = (deltaX * deltaX) + (deltaY * deltaY);
  double dot1 = dot2d(p1.vx - p2.vx, p1.vy - p2.vy, p1.x - p2.x, p1.y - p2.y);
  double dot2 = dot2d(p2.vx - p1.vx, p2.vy - p1.vy, p2.x - p1.x, p2.y - p1.y);
  double vx1 = p1.vx - (dot1 * (p1.x - p2.x) / deltaMagSquared);
  double vy1 = p1.vy - (dot1 * (p1.y - p2.y) / deltaMagSquared);
  double vx2 = p2.vx - (dot2 * (p2.x - p1.x) / deltaMagSquared);
  double vy2 = p2.vy - (dot2 * (p2.y - p1.y) / deltaMagSquared);
  
  p1.update(newX1, newY1, vx1, vy1);
  p2.update(newX2, newY2, vx2, vy2);

}


// Updates a particle's position to remain in the box, xi is the position vector
// Source: Krauth Algo 2.5
void box_it(double* xi)
{
  double x = std::fmod(xi[0], WALL_XMAX - WALL_XMIN);
  if(x < 0) x += WALL_XMAX - WALL_XMIN;
  double y = std::fmod(xi[1], WALL_YMAX - WALL_YMIN);
  if(y < 0) y += WALL_YMAX - WALL_YMIN;
  
  xi[0] = x;
  xi[1] = y;
}


// Calculates the distance between two particles in the periodic boundary
// case, may be able to utilized in the particle collision kinematics as normal
// Source: Krauth Algo 2.6
//@param : xi double array of length 2
double* diff_vec(Particle &p1, Particle &p2, double xi[])
{
 
  xi[0] = p1.x - p2.x;
  xi[1] = p1.y - p2.y;
  box_it(xi);
  if(xi[0] > (WALL_XMAX - WALL_XMIN) / 2) xi[0] -= (WALL_XMAX - WALL_XMIN);
  if(xi[1] > (WALL_YMAX - WALL_YMIN) / 2) xi[1] -= (WALL_YMAX - WALL_YMIN);

  return xi;
}


//--------------------------------------------------------------- Propagation and Updating Functions --------------------------------------------------//

/*
  Propagate all the particles in particles except those specified by dontProp1/2 for a time
 */
void propagateAll(vector<Particle> *particles, double time, int dontPropP1, int dontPropP2)
{
  for (int pInd = 0; pInd < N; pInd++)
    {
      if (pInd == dontPropP1 || pInd == dontPropP2)
	continue;
      else
	particles->at(pInd).propagate(time);
    }
}


//----------------------------------------------------------------     Visualization and Debugging Utility Functions      -----------------------------//

void printInteractionMatrix(double matrix[][N+4])
{
  for (int r = 0; r < N; r++)
    {
      for (int c = 0; c < N + 4; c++)
	{
	  printf("%8.3g\t", matrix[r][c]);
	}
      printf("\n");
    }
}


//Display a visualization of the current state
void visualize(vector<Particle> *particles, TCanvas *canv, int pad)
{
  canv->cd(pad);
  TH2F *simStates[N];
  TH2F *projStates[N];
  string simName = "simState";
  string projName = "projState";

  for (int pInd = 0; pInd < N; pInd++)
    {
      simStates[pInd] = new TH2F((simName + to_string(pInd)).c_str(), "Current State", 50, WALL_XMIN, WALL_XMAX, 50 , WALL_YMIN, WALL_YMAX);
      projStates[pInd] = new TH2F((projName + to_string(pInd)).c_str(), "Projected State", 50, WALL_XMIN, WALL_XMAX, 50 , WALL_YMIN, WALL_YMAX);
      simStates[pInd]->SetXTitle("x");
      simStates[pInd]->SetYTitle("y");
      simStates[pInd]->SetMarkerStyle(8); //Solid circle markers
      projStates[pInd]->SetMarkerStyle(4); //Hollow circles for projections
      simStates[pInd]->SetMarkerColor(pInd+1);
      projStates[pInd]->SetMarkerColor(pInd+1);

      Particle part = particles->at(pInd);
      

      simStates[pInd]->Fill(part.x, part.y);


      double projX = part.x + part.vx;
      double projY = part.y + part.vy;
      if (projX - part.d/2 < WALL_XMIN)
	projX = WALL_XMIN + part.d/2;
      else if (projX + part.d/2 > WALL_XMAX)
	projY = WALL_XMAX - part.d/2;

      if (projY - part.d/2 < WALL_YMIN)
	projY = WALL_YMIN + part.d/2;
      else if (projX + part.d/2 > WALL_YMAX)
	projY = WALL_YMAX - part.d/2;

      projStates[pInd]->Fill(projX, projY);  
 
      simStates[pInd]->Draw("SCAT SAME");
      projStates[pInd]->Draw("SCAT SAME");
    }

}


